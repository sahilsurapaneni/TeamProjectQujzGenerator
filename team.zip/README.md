README

Course: cs400
Semester: Spring 2019
Project name: Practice Quiz Generator
Team Members:
1. Sahil Surapaneni, Lec 002, and surapaneni2@wisc.edu
2. Maurya Pulipati, Lec 001, and mpulipati@wisc.edu
3. Chad Spalding, Lec 004, and ctspalding@wisc.edu
4. Varun Sudhakaran, Lec 002, vsudhakaran@wisc.edu
5. Sathvik Gurupalli, Lec 004, and gurupalli@wisc.edu

Notes or comments to the grader:
